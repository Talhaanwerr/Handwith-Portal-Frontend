"use client";

import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Loader2, ShieldOff, ShieldCheck, XCircle, AlertCircle } from "lucide-react";
import { StatusBadge } from "@/components/ui/status-badge";
import { ConfirmDialog } from "@/components/ui/confirm-dialog";
import { Button } from "@/components/ui/button";
import { tenantsApi } from "@/lib/tenants-api";
import { TENANTS_QUERY_KEY, TENANT_DETAIL_QUERY_KEY } from "@/constants/query-keys";
import { ApiError } from "@/lib/api-error";

interface TenantDetailViewProps {
  tenantId: string;
}

type StatusAction = "suspend" | "activate" | "cancel";

export function TenantDetailView({ tenantId }: TenantDetailViewProps) {
  const qc = useQueryClient();
  const [dialog, setDialog] = useState<StatusAction | null>(null);
  const [isActing, setIsActing] = useState(false);
  const [actionError, setActionError] = useState("");

  const {
    data: res,
    isLoading,
    isError,
  } = useQuery({
    queryKey: [TENANT_DETAIL_QUERY_KEY, tenantId],
    queryFn: () => tenantsApi.getOne(tenantId),
  });

  const tenant = res?.data;

  async function handleAction(act: StatusAction) {
    setIsActing(true);
    setActionError("");
    try {
      if (act === "suspend") await tenantsApi.suspend(tenantId);
      else if (act === "activate") await tenantsApi.activate(tenantId);
      else await tenantsApi.cancel(tenantId);

      await qc.invalidateQueries({ queryKey: [TENANT_DETAIL_QUERY_KEY, tenantId] });
      await qc.invalidateQueries({ queryKey: [TENANTS_QUERY_KEY] });
    } catch (err) {
      setActionError(err instanceof ApiError ? err.message : "Action failed.");
    } finally {
      setIsActing(false);
      setDialog(null);
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="h-6 w-6 animate-spin text-slate-400" />
      </div>
    );
  }

  if (isError || !tenant) {
    return (
      <div className="flex items-center gap-3 rounded-xl border border-red-200 bg-red-50 p-6 text-sm text-red-600">
        <AlertCircle className="h-5 w-5 shrink-0" />
        Failed to load tenant. Please try again.
      </div>
    );
  }

  const initials = tenant.name.slice(0, 2).toUpperCase();

  const details = [
    { label: "Slug", value: tenant.slug },
    { label: "Domain", value: tenant.domain ?? "—" },
    { label: "Plan", value: tenant.subscriptions?.[0]?.plan?.name ?? "—" },
    { label: "Users", value: String(tenant._count?.users ?? "—") },
    { label: "Timezone", value: tenant.timezone ?? "—" },
    { label: "Created", value: new Date(tenant.createdAt).toLocaleDateString() },
  ];

  return (
    <div className="space-y-6">
      {actionError && (
        <div className="flex items-center gap-3 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-600">
          <AlertCircle className="h-4 w-4 shrink-0" />
          {actionError}
        </div>
      )}

      {/* Info card */}
      <div className="rounded-xl border border-slate-200 bg-white p-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="bg-primary/10 flex h-12 w-12 items-center justify-center rounded-xl">
                <span className="text-primary text-xl font-bold">{initials}</span>
              </div>
              <div>
                <h2 className="text-lg font-semibold text-slate-900">{tenant.name}</h2>
                <p className="text-sm text-slate-400">/{tenant.slug}</p>
              </div>
            </div>
            <StatusBadge status={tenant.status} />
          </div>

          <div className="flex flex-wrap gap-2">
            {tenant.status !== "ACTIVE" && (
              <Button variant="outline" size="sm" onClick={() => setDialog("activate")}>
                <ShieldCheck className="h-4 w-4 text-green-600" />
                Activate
              </Button>
            )}
            {tenant.status === "ACTIVE" && (
              <Button variant="outline" size="sm" onClick={() => setDialog("suspend")}>
                <ShieldOff className="h-4 w-4 text-yellow-600" />
                Suspend
              </Button>
            )}
            {tenant.status !== "CANCELLED" && (
              <Button variant="outline" size="sm" onClick={() => setDialog("cancel")}>
                <XCircle className="h-4 w-4 text-red-600" />
                Cancel
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Details grid */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {details.map(({ label, value }) => (
          <div key={label} className="rounded-xl border border-slate-200 bg-white p-4">
            <p className="text-xs font-medium tracking-wide text-slate-400 uppercase">{label}</p>
            <p className="mt-1 text-sm font-medium text-slate-900">{value}</p>
          </div>
        ))}
      </div>

      {/* Subscription table (if any) */}
      {(tenant.subscriptions?.length ?? 0) > 0 && (
        <div className="rounded-xl border border-slate-200 bg-white p-6">
          <h3 className="mb-4 text-sm font-semibold text-slate-700">Subscriptions</h3>
          <div className="divide-y divide-slate-100">
            {tenant.subscriptions.map((sub) => (
              <div key={sub.id} className="flex items-center justify-between py-3 text-sm">
                <span className="font-medium text-slate-900">{sub.plan.name}</span>
                <StatusBadge status={sub.status} />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Confirm dialogs */}
      <ConfirmDialog
        open={dialog === "suspend"}
        onClose={() => setDialog(null)}
        onConfirm={() => handleAction("suspend")}
        title="Suspend Tenant"
        description="This will prevent all users of this tenant from accessing the platform."
        confirmLabel="Suspend"
        variant="destructive"
        isLoading={isActing}
      />
      <ConfirmDialog
        open={dialog === "activate"}
        onClose={() => setDialog(null)}
        onConfirm={() => handleAction("activate")}
        title="Activate Tenant"
        description="This will restore access for all users of this tenant."
        confirmLabel="Activate"
        isLoading={isActing}
      />
      <ConfirmDialog
        open={dialog === "cancel"}
        onClose={() => setDialog(null)}
        onConfirm={() => handleAction("cancel")}
        title="Cancel Tenant"
        description="This will permanently cancel the tenant. This action cannot be undone."
        confirmLabel="Cancel Tenant"
        variant="destructive"
        isLoading={isActing}
      />
    </div>
  );
}
